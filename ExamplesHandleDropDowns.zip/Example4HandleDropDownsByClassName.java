package Android_Native_Apps;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class Example4HandleDropDownsByClassName {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		DesiredCapabilities dc= new DesiredCapabilities();
		
		dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "Appium");
		
		dc.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		
		dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, "5.1");//Version is number here
		
		dc.setCapability(MobileCapabilityType.DEVICE_NAME, "Android");
		
		dc.setCapability(MobileCapabilityType.APP, "C:\\apkfiles\\AndroidUI.apk");
		
		URL url =new URL("http://127.0.0.1:4723/wd/hub");

		AndroidDriver<WebElement> driver= new AndroidDriver<WebElement>(url,dc);
		
		///handling drop-downs
				
		driver.findElementById("android:id/text1").click();//click on dropdown
		
		List <WebElement> options=driver.findElementsByClassName("android.widget.CheckedTextView");//using class name
		
		System.out.println("Total number of options available in dropdown:"+options.size());
		
		
		for(WebElement e:options)
		{
			String val=e.getText();
			
			if(val.equalsIgnoreCase("INDIA"))
			{
				e.click();
				break;
			}
		}
		
		Thread.sleep(8000);	
		
		driver.quit();
		
	}

}
